To run project successfully , 
	ist make a data base of name DATABASE_project
	Import all the sql files i.e(tables) into this database
	
	The ist page of my project is home.html, go to the url of the home.html
	Now we can use project and do all the operations.

Thank You
